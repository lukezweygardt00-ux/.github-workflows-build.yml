package com.mutantvillager;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.command.IEntitySelector;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIAvoidEntity;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.monster.EntityGolem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

/**
 * A hulking mutant villager. Fights every hostile mob (except creepers, which it runs from),
 * grunts with deep, "auto-tuned" villager sounds and drops trap parts.
 */
public class EntityMutantVillager extends EntityGolem {

    /** Melee swing animation clock, 0..23 while swinging, -1 when idle. Runs on both sides. */
    public int swingTick = -1;
    private Entity swingTarget;

    /** Auto-tune notes (major pentatonic, pitch 0.5 = the lowest the game allows). */
    private static final float[] NOTES = {0.5F, 0.5625F, 0.625F, 0.75F, 0.8333F};

    /** Hostile mobs only, and not creepers (it avoids those instead). */
    private static final IEntitySelector HOSTILE = new IEntitySelector() {
        @Override
        public boolean isEntityApplicable(Entity entity) {
            return entity instanceof IMob && !(entity instanceof EntityCreeper);
        }
    };

    public EntityMutantVillager(World world) {
        super(world);
        setSize(1.4F, 2.5F);
        getNavigator().setAvoidsWater(true);

        tasks.addTask(0, new EntityAISwimming(this));
        tasks.addTask(1, new EntityAIAvoidEntity(this, EntityCreeper.class, 8.0F, 0.9D, 1.2D));
        tasks.addTask(2, new EntityAIAttackOnCollide(this, 1.0D, true));
        tasks.addTask(3, new EntityAIWander(this, 0.6D));
        tasks.addTask(4, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        tasks.addTask(5, new EntityAILookIdle(this));

        targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
        targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityLiving.class, 0, true, false, HOSTILE));
    }

    @Override
    public boolean isAIEnabled() {
        return true;
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(60.0D);
        getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.28D);
        getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(0.5D);
        getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(32.0D);
        getAttributeMap().registerAttribute(SharedMonsterAttributes.attackDamage);
        getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(8.0D);
    }

    // ---------------------------------------------------------------- combat

    /** Called by the attack AI when in reach: starts the swing; the hit lands mid-swing. */
    @Override
    public boolean attackEntityAsMob(Entity target) {
        if (swingTick < 0) {
            swingTick = 0;
            swingTarget = target;
            worldObj.setEntityState(this, (byte) 4);
            playSound("mob.villager.no", 1.0F, 1.0F);
        }
        return true;
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();

        if (swingTick >= 0) {
            swingTick++;

            if (!worldObj.isRemote && swingTick == 9 && swingTarget != null && swingTarget.isEntityAlive()
                    && getDistanceSqToEntity(swingTarget) < 25.0D) {
                float damage = (float) getEntityAttribute(SharedMonsterAttributes.attackDamage).getAttributeValue();
                if (swingTarget.attackEntityFrom(DamageSource.causeMobDamage(this), damage)) {
                    double dx = swingTarget.posX - posX;
                    double dz = swingTarget.posZ - posZ;
                    double len = Math.sqrt(dx * dx + dz * dz);
                    if (len > 0.001D) {
                        swingTarget.motionX += dx / len * 0.6D;
                        swingTarget.motionZ += dz / len * 0.6D;
                    }
                    swingTarget.motionY += 0.4D;
                }
            }

            if (swingTick >= 24) {
                swingTick = -1;
                swingTarget = null;
            }
        }
    }

    /** Client: the server says a swing started. */
    @Override
    @SideOnly(Side.CLIENT)
    public void handleHealthUpdate(byte id) {
        if (id == 4) {
            swingTick = 0;
        } else {
            super.handleHealthUpdate(id);
        }
    }

    // ---------------------------------------------------------------- sounds

    /** Every villager sound is re-pitched to a low scale note, so the grunts sound "auto-tuned". */
    @Override
    public void playSound(String name, float volume, float pitch) {
        if (name != null && name.startsWith("mob.villager")) {
            boolean heavy = name.endsWith(".hit") || name.endsWith(".death");
            pitch = heavy ? NOTES[rand.nextInt(2)] : NOTES[rand.nextInt(NOTES.length)];
            volume = volume * 1.4F;
        }
        super.playSound(name, volume, pitch);
    }

    @Override
    protected String getLivingSound() {
        return "mob.villager.idle";
    }

    @Override
    protected String getHurtSound() {
        return "mob.villager.hit";
    }

    @Override
    protected String getDeathSound() {
        return "mob.villager.death";
    }

    // ---------------------------------------------------------------- misc

    /** Trap parts: tripwire hooks, string, cobwebs, pressure plates, trapdoors. */
    @Override
    protected void dropFewItems(boolean recentlyHit, int looting) {
        entityDropItem(new ItemStack(Blocks.tripwire_hook, 1 + rand.nextInt(2 + looting)), 0.0F);
        entityDropItem(new ItemStack(Items.string, 1 + rand.nextInt(3 + looting)), 0.0F);
        if (rand.nextInt(2) == 0) {
            entityDropItem(new ItemStack(Blocks.web, 1 + rand.nextInt(2)), 0.0F);
        }
        if (rand.nextInt(2) == 0) {
            entityDropItem(new ItemStack(Blocks.stone_pressure_plate, 1), 0.0F);
        }
        if (rand.nextInt(3) == 0) {
            entityDropItem(new ItemStack(Blocks.trapdoor, 1), 0.0F);
        }
    }

    @Override
    protected boolean canDespawn() {
        return false;
    }
}
