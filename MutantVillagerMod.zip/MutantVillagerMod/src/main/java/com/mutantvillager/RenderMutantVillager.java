package com.mutantvillager;

import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class RenderMutantVillager extends RenderLiving {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(MutantVillagerMod.MODID, "textures/entity/mutant_villager.png");

    public RenderMutantVillager() {
        super(new ModelMutantVillager(), 0.9F);
    }

    /** The hunched model's feet float ~1.3 px above the ground; nudge it down so it stands on the floor. */
    @Override
    protected void preRenderCallback(EntityLivingBase entity, float partialTicks) {
        GL11.glTranslatef(0.0F, 0.08F, 0.0F);
    }

    @Override
    protected ResourceLocation getEntityTexture(Entity entity) {
        return TEXTURE;
    }
}
