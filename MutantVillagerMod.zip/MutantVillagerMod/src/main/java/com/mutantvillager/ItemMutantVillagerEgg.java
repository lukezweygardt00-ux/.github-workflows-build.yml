package com.mutantvillager;

import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Facing;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

/** Spawn egg for the Mutant Villager. */
public class ItemMutantVillagerEgg extends Item {

    public ItemMutantVillagerEgg() {
        setUnlocalizedName("mutantVillagerEgg");
        setTextureName(MutantVillagerMod.MODID + ":mutant_villager_egg");
        setCreativeTab(CreativeTabs.tabMisc);
    }

    @Override
    public boolean onItemUse(ItemStack stack, EntityPlayer player, World world, int x, int y, int z,
                             int side, float hitX, float hitY, float hitZ) {
        if (world.isRemote) {
            return true;
        }

        Block block = world.getBlock(x, y, z);
        x += Facing.offsetsXForSide[side];
        y += Facing.offsetsYForSide[side];
        z += Facing.offsetsZForSide[side];

        if (!player.canPlayerEdit(x, y, z, side, stack)) {
            return false;
        }

        double yOffset = 0.0D;
        if (side == 1 && block.getRenderType() == 11) {
            yOffset = 0.5D;
        }

        EntityMutantVillager mob = new EntityMutantVillager(world);
        mob.setLocationAndAngles(x + 0.5D, y + yOffset, z + 0.5D,
                MathHelper.wrapAngleTo180_float(world.rand.nextFloat() * 360.0F), 0.0F);
        mob.rotationYawHead = mob.rotationYaw;
        mob.renderYawOffset = mob.rotationYaw;
        world.spawnEntityInWorld(mob);
        mob.playLivingSound();

        if (!player.capabilities.isCreativeMode) {
            stack.stackSize--;
        }
        return true;
    }
}
