package com.mutantvillager;

public class CommonProxy {

    public void registerRenderers() {
        // server: nothing to render
    }
}
