package com.mutantvillager;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

/**
 * Same body, proportions, hunched pose and swing animation as the Mutant Zombie model,
 * with the villager head (and nose) in place of the zombie head.
 */
public class ModelMutantVillager extends ModelBase {

    private static final float PI = 3.1415927F;

    public ModelRenderer pelvis;
    public ModelRenderer waist;
    public ModelRenderer chest;
    public ModelRenderer head;      // villager head + nose
    public ModelRenderer arm1;
    public ModelRenderer arm2;
    public ModelRenderer forearm1;
    public ModelRenderer forearm2;
    public ModelRenderer leg1;
    public ModelRenderer leg2;
    public ModelRenderer foreleg1;
    public ModelRenderer foreleg2;

    private float partial;

    public ModelMutantVillager() {
        textureWidth = 128;
        textureHeight = 128;

        pelvis = new ModelRenderer(this);
        pelvis.setRotationPoint(0.0F, 10.0F, 6.0F);

        waist = new ModelRenderer(this, 0, 44);
        waist.addBox(-7.0F, -16.0F, -6.0F, 14, 16, 12);
        pelvis.addChild(waist);

        chest = new ModelRenderer(this, 0, 16);
        chest.addBox(-12.0F, -12.0F, -8.0F, 24, 12, 16);
        chest.setRotationPoint(0.0F, -12.0F, 0.0F);
        waist.addChild(chest);

        head = new ModelRenderer(this);
        head.setTextureOffset(0, 72).addBox(-4.0F, -10.0F, -4.0F, 8, 10, 8);
        head.setTextureOffset(24, 72).addBox(-1.0F, -3.0F, -6.0F, 2, 4, 2);
        head.setRotationPoint(0.0F, -11.0F, -4.0F);
        chest.addChild(head);

        arm1 = new ModelRenderer(this, 104, 0);
        arm1.addBox(-3.0F, 0.0F, -3.0F, 6, 16, 6);
        arm1.setRotationPoint(-11.0F, -8.0F, 2.0F);
        chest.addChild(arm1);

        arm2 = new ModelRenderer(this, 104, 0);
        arm2.mirror = true;
        arm2.addBox(-3.0F, 0.0F, -3.0F, 6, 16, 6);
        arm2.setRotationPoint(11.0F, -8.0F, 2.0F);
        chest.addChild(arm2);

        forearm1 = new ModelRenderer(this, 104, 22);
        forearm1.addBox(-3.0F, 0.0F, -3.0F, 6, 16, 6, 0.1F);
        forearm1.setRotationPoint(0.0F, 14.0F, 0.0F);
        arm1.addChild(forearm1);

        forearm2 = new ModelRenderer(this, 104, 22);
        forearm2.mirror = true;
        forearm2.addBox(-3.0F, 0.0F, -3.0F, 6, 16, 6, 0.1F);
        forearm2.setRotationPoint(0.0F, 14.0F, 0.0F);
        arm2.addChild(forearm2);

        leg1 = new ModelRenderer(this, 80, 0);
        leg1.addBox(-3.0F, 0.0F, -3.0F, 6, 11, 6);
        leg1.setRotationPoint(-5.0F, -2.0F, 0.0F);
        pelvis.addChild(leg1);

        leg2 = new ModelRenderer(this, 80, 0);
        leg2.mirror = true;
        leg2.addBox(-3.0F, 0.0F, -3.0F, 6, 11, 6);
        leg2.setRotationPoint(5.0F, -2.0F, 0.0F);
        pelvis.addChild(leg2);

        foreleg1 = new ModelRenderer(this, 80, 17);
        foreleg1.addBox(-3.0F, 0.0F, -3.0F, 6, 8, 6, 0.1F);
        foreleg1.setRotationPoint(0.0F, 9.5F, 0.0F);
        leg1.addChild(foreleg1);

        foreleg2 = new ModelRenderer(this, 80, 17);
        foreleg2.mirror = true;
        foreleg2.addBox(-3.0F, 0.0F, -3.0F, 6, 8, 6, 0.1F);
        foreleg2.setRotationPoint(0.0F, 9.5F, 0.0F);
        leg2.addChild(foreleg2);
    }

    @Override
    public void render(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                       float netHeadYaw, float headPitch, float scale) {
        EntityMutantVillager mob = (EntityMutantVillager) entity;
        setAngles();
        partial = ageInTicks - mob.ticksExisted;
        animate(mob, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        pelvis.render(scale);
    }

    /** The resting (hunched) pose. */
    private void setAngles() {
        pelvis.rotationPointY = 10.0F;
        waist.rotateAngleX = 0.19634955F;
        chest.rotateAngleX = 0.5235988F;
        chest.rotateAngleY = 0.0F;
        head.rotateAngleX = -0.71994835F;
        head.rotateAngleY = 0.0F;
        head.rotateAngleZ = 0.0F;
        arm1.rotateAngleX = -0.32724923F;
        arm1.rotateAngleY = 0.0F;
        arm1.rotateAngleZ = 0.3926991F;
        arm2.rotateAngleX = -0.32724923F;
        arm2.rotateAngleY = 0.0F;
        arm2.rotateAngleZ = -0.3926991F;
        forearm1.rotateAngleX = -1.0471976F;
        forearm2.rotateAngleX = -1.0471976F;
        leg1.rotateAngleX = -0.7853982F;
        leg1.rotateAngleY = 0.0F;
        leg1.rotateAngleZ = 0.0F;
        leg2.rotateAngleX = -0.7853982F;
        leg2.rotateAngleY = 0.0F;
        leg2.rotateAngleZ = 0.0F;
        foreleg1.rotateAngleX = 0.7853982F;
        foreleg2.rotateAngleX = 0.7853982F;
    }

    private void animate(EntityMutantVillager mob, float f, float f2, float age, float yawDeg, float pitchDeg) {
        float legA = (MathHelper.sin((f - 0.7F) * 0.4F) + 0.7F) * f2;
        float legB = -(MathHelper.sin((f + 0.7F) * 0.4F) - 0.7F) * f2;
        float bob = MathHelper.sin(f * 0.4F) * f2;
        float breath = MathHelper.sin(age * 0.1F);
        float yaw = yawDeg * PI / 180.0F;
        float pitch = pitchDeg * PI / 180.0F;

        if (mob.swingTick >= 0) {
            animateMelee(mob.swingTick);
        }

        chest.rotateAngleX += breath * 0.02F;
        arm1.rotateAngleZ -= breath * 0.05F;
        arm2.rotateAngleZ += breath * 0.05F;

        head.rotateAngleX += pitch * 0.6F;
        head.rotateAngleY += yaw * 0.8F;
        head.rotateAngleZ -= yaw * 0.2F;
        chest.rotateAngleX += pitch * 0.4F;
        chest.rotateAngleY += yaw * 0.2F;

        pelvis.rotationPointY += MathHelper.sin(f * 0.8F) * f2 * 0.5F;
        chest.rotateAngleY -= bob * 0.1F;
        arm1.rotateAngleX -= bob * 0.6F;
        arm2.rotateAngleX += bob * 0.6F;
        leg1.rotateAngleX += legA * 0.9F;
        leg2.rotateAngleX += legB * 0.9F;
    }

    /** Swing: wind up (0-8), slam (8-12), hold (12-16), recover (16-24). */
    private void animateMelee(int t) {
        arm1.rotateAngleZ = 0.0F;
        arm2.rotateAngleZ = 0.0F;

        if (t < 8) {
            float p = (t + partial) / 8.0F;
            float a = -MathHelper.sin(p * PI / 2.0F);
            float b = MathHelper.cos(p * PI / 2.0F);
            waist.rotateAngleX += a * 0.2F;
            chest.rotateAngleX += a * 0.2F;
            arm1.rotateAngleX += a * 2.3F;
            arm1.rotateAngleZ += b * PI / 8.0F;
            arm2.rotateAngleX += a * 2.3F;
            arm2.rotateAngleZ -= b * PI / 8.0F;
            forearm1.rotateAngleX += a * 0.8F;
            forearm2.rotateAngleX += a * 0.8F;
        } else if (t < 12) {
            float p = (t - 8 + partial) / 4.0F;
            float a = -MathHelper.cos(p * PI / 2.0F);
            float b = MathHelper.sin(p * PI / 2.0F);
            waist.rotateAngleX += a * 0.9F + 0.7F;
            chest.rotateAngleX += a * 0.9F + 0.7F;
            arm1.rotateAngleX += a * 0.2F - 2.1F;
            arm1.rotateAngleZ += b * 0.3F;
            arm2.rotateAngleX += a * 0.2F - 2.1F;
            arm2.rotateAngleZ -= b * 0.3F;
            forearm1.rotateAngleX += a * 1.0F + 0.2F;
            forearm2.rotateAngleX += a * 1.0F + 0.2F;
        } else if (t < 16) {
            waist.rotateAngleX += 0.7F;
            chest.rotateAngleX += 0.7F;
            arm1.rotateAngleX -= 2.1F;
            arm1.rotateAngleZ += 0.3F;
            arm2.rotateAngleX -= 2.1F;
            arm2.rotateAngleZ -= 0.3F;
            forearm1.rotateAngleX += 0.2F;
            forearm2.rotateAngleX += 0.2F;
        } else if (t < 24) {
            float p = (t - 16 + partial) / 8.0F;
            float a = MathHelper.cos(p * PI / 2.0F);
            waist.rotateAngleX += a * 0.7F;
            chest.rotateAngleX += a * 0.7F;
            arm1.rotateAngleX -= a * 2.1F;
            arm1.rotateAngleZ += a * -0.09269908F + 0.3926991F;
            arm2.rotateAngleX -= a * 2.1F;
            arm2.rotateAngleZ -= a * -0.09269908F + 0.3926991F;
            forearm1.rotateAngleX += a * 0.2F;
            forearm2.rotateAngleX += a * 0.2F;
        } else {
            arm1.rotateAngleZ += 0.3926991F;
            arm2.rotateAngleZ += -0.3926991F;
        }
    }
}
