package com.mutantvillager;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.registry.EntityRegistry;
import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.item.Item;

@Mod(modid = MutantVillagerMod.MODID, name = "Mutant Villager", version = MutantVillagerMod.VERSION)
public class MutantVillagerMod {

    public static final String MODID = "mutantvillager";
    public static final String VERSION = "1.0.0";

    @Mod.Instance(MODID)
    public static MutantVillagerMod instance;

    @SidedProxy(clientSide = "com.mutantvillager.ClientProxy", serverSide = "com.mutantvillager.CommonProxy")
    public static CommonProxy proxy;

    public static Item egg;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        EntityRegistry.registerModEntity(EntityMutantVillager.class, "MutantVillager", 0, this, 80, 3, true);

        egg = new ItemMutantVillagerEgg();
        GameRegistry.registerItem(egg, "mutantVillagerEgg");

        proxy.registerRenderers();
    }
}
