# Mutant Villager (Minecraft 1.7.10, Forge 10.13.4.1614)

Mutant Villager Spawn Egg (Misc tab). The mob uses the Mutant Zombie body, pose and swing animation with a villager head.

* 60 health, 8 attack damage (4 hearts), slower than a player sprinting.
* Attacks every hostile mob (zombies, skeletons, spiders...) but runs from creepers. Never attacks players unless hit by one.
* Deep villager voice: all villager sounds re-pitched to a low pentatonic scale ("auto-tune").
* Drops trap parts: tripwire hooks, string, cobwebs, stone pressure plates, trapdoors.
